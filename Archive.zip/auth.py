
#Authentication Tokens
access_token = "56163769-bAoCgZQ3HXEtaNawyhLolczjFyi9mpInsfRsglwyx"
access_token_secret = "vR8I7IwzAUDqLQfJPFMbpOtSbOaENmg4OorvJ4A0CukfC"

bearer_token = "AAAAAAAAAAAAAAAAAAAAAOPFVgEAAAAA6LCGNp5nBsfcqvld%2FJ%2FHgZhF7RM%3Dw3TD9TXthlO3lKGdHikKsZC84EdnspmqVLEUEAe6GhnNyW6LQe"

#consumer keys
api_key = "6YkD2N1TcHC0eCQFLjifLHsCh"
api_key_secret = "YsnVrFmJ2Lo5gnCN13MaUfETBuJptr8pmEIGzErSEQbh5DR2CZ"

#OAuth 2.0 Client ID and Client Secret
client_ID = "RDdvcmI5Z3BmLWoyOXp2LTA4U2Q6MTpjaQ"
client_secret = "qm_3F6FJD33WRmCUroG33OpUxI4cBEoZtQA3OpftMV5fsOx7x-"